package com.example.instagram3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri selectedImageUri;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        Button selectImageBtn = findViewById(R.id.selectImageBtn);
        Button shareToInstagramBtn = findViewById(R.id.shareToInstagramBtn);

        // BBoton para sellecionar imagen

        selectImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageSelector();
            }
        });

        // Boton para compartir imagen a Instagram

        shareToInstagramBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareImageToInstagram();
            }
        });
    }

    // Abre la galeria para seleccionar imagen
    private void openImageSelector() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    //Maneja el resultado de la seleccion de imagen, AKA URI padrino
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            imageView.setImageURI(selectedImageUri);
        }
    }

    //Comparte la imagen seleccionada a Instagram
    private void shareImageToInstagram() {
        if (selectedImageUri != null) {
            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.setType("image/*");
            shareIntent.putExtra(Intent.EXTRA_STREAM, selectedImageUri);

            //Se establece Instagram como el app destino
            shareIntent.setPackage("com.instagram.android");

            //Se checa si Instagram esta instalado mediante getPackageManager
            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(shareIntent);
            } else {
                //Si Instagram no está instalado, se avisa al usuario
                startActivity(Intent.createChooser(shareIntent, "Share Image"));
            }
        }
    }
}